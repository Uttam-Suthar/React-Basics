import MovieList from "./MovieList";

export default function App(){
  return(
    <>
    <h1>Movie App</h1>
    <MovieList />
    </>

  )
}