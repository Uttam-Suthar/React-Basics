import "./styles.css";
// import { Card } from "./Card";

// export function Card(props) {
//   const { name, about } = props
//   return (
//     <>
//       <div className="card">
//         <h3>Name: {name}</h3>
//         <span>About: {about}</span>
//       </div>
//     </>
//   )
// }
export const Card = (props) => (
  <div className="card">
    <h3>{props.name}</h3>
    <span>{props.about}</span>
  </div>
);


export default function App() {
  return <Card name="Your Name." about="Your Message." />;
}
