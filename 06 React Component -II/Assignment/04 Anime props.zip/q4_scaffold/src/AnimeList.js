import { Component } from "react";
import AnimeCard from "./AnimeCard";

// Complete the AnimeList Component
class AnimeList extends Component {
  render() {
    const {anime}= this.props
    return <div className="anime-list">
      {anime.map((item,index)=>(
        <AnimeCard key={index} name={item.name} image={item.image}/>
      ))}
    </div>;
  }
}

export default AnimeList;
