import MovieCard from "./MovieCard";

export default function App(){
  return(
    <>
    <h1>Movie App</h1>
    <MovieCard />
    </>

  )
}