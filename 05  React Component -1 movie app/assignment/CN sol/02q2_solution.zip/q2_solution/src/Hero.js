import { Component } from "react";

class Hero extends Component {
  render() {
    return (
      <div>
        <h3>Name: Your Name</h3>
        <p>Email: youremail@gmail.com</p>
        <p>Phone: 1234567890</p>
        <p>Address: ABC, xyz street.</p>
      </div>
    );
  }
}

export default Hero;
