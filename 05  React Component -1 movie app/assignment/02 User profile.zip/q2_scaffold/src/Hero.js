import React from "react";
import Skills from "./Skills";
import About from "./About";

class Hero extends React.Component {
    render() {
        return (
            <div className="main">
                <div>
                    <h3>Name: Pranav Sharad yeole </h3>
                    <p>Email: pranav@google.com</p>
                    <p>Phone: 8546465544</p>
                    <p>Address: ABC,xyz,street.</p>
                </div>
                <Skills />
                <About />
            </div>
        )
    }
}

export default Hero