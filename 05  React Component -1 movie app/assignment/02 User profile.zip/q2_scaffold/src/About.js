
import React from "react";

class About extends React.Component {
    render() {
        return (

            <p>Hi, My name is Pranav. I am a full stack web developer and i have developed servel projects with MERN stack. I am also familar with Python and Django. </p>

        )
    }
}

export default About