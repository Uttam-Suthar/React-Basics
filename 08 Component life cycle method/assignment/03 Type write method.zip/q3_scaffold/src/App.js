import React from "react";
import Name from "./components/Name";
import "./styles.css";

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      showName: false
    };

    this.intervalId = null;
  }

  // Function to toggle the showName state
  toggleShowName = () => {
    this.setState((prevState) => ({
      showName: !prevState.showName
    }), () => {
      if (this.state.showName) {
        // Start the typing effect
        this.intervalId = setInterval(() => {
          this.refs.nameRef.typeWriterEffect();
        }, 500);
      } else {
        // Stop the typing effect
        clearInterval(this.intervalId);
      }
    });

  };


  render() {
    return (
      <div className="App">
        <button onClick={this.toggleShowName} className="button-85">
          {this.state.showName ? "Stop" : "Start"}
        </button>
        <Name showName={this.state.showName} ref="nameRef" />
      </div>
    );
  }
}
