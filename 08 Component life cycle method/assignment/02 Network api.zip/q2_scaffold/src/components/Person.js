import { Component } from "react";

class Person extends Component {
  // Define appropriate lifecycle method to show alert here
  // componentDidMount() {
  //   // This lifecycle method is called after the component is inserted into the DOM.
  //   // alert(`Person with email ${this.props.person.email} mounted.`);
  //   // alert(`Person with email ${this.props.person.email} mounted.`);
  // }
  componentWillUnmount() {
    // Display an alert when the component is about to be removed
    alert(`${this.props.person.email} will be removed from the network`);
  }

  render() {
    const { img, email } = this.props.person;
    return (
      <div className="person">
        <b onClick={() => this.props.onRemove(this.props.index)}>X</b>
        <img alt={email} src={img} />
        <p>{email}</p>
      </div>
    );
  }
}

export default Person;
