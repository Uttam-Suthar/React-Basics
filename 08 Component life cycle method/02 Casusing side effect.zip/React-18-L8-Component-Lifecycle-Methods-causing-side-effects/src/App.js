import React from "react";
import ComponentA from "./Components/ComponentA";

class App extends React.Component {

  render() {
    return (
      <>
        <ComponentA />
      </>
    );
  }
}

export default App;
