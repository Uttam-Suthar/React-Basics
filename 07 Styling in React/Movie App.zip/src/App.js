import React from 'react';
// import './App.css';
// import HeadingOne from './HeadingOne';
// import HeadingTwo from './HeadingTwo';
// import Student from './Student';
import MovieList from './Movielist';
import Navbar from './Navbar'
import { movies } from './moviesData';


import "./index.css"


class App extends React.Component{
  constructor() {
    // super()
    // this.state = {
    //     title: "The Avenger",
    //     plot: "Supernatural power show in movie",
    //     price: 199,
    //     rating: 8.9,
    //     stars: 0,
    //     fav: false,
    //     isInCart: false
    // }

    super()
    this.state = {
      movies: movies,
      cartCount: 0
    }

    // this.addStar= this.addStar.bind(this)
  }

  handleStar = (movie) => {
    const { movies } = this.state
    // const mid= this.state.movies.indexOf(movie)
    const mid = movies.indexOf(movie)

    if (movies[mid].stars >= 5) {
      return
    }
    movies[mid].stars += 0.5

    this.setState({
      movies: movies
    })
  }

  handDecStars = (movie) => {
    const { movies } = this.state
    // const mid= this.state.movies.indexOf(movie)
    const mid = movies.indexOf(movie)

    if (movies[mid].stars <= 0) {
      return
    }
    movies[mid].stars -= 0.5

    this.setState({
      movies: movies
    })
  }

  handleToggleFav = (movie) => {
    const { movies } = this.state
    // const mid= this.state.movies.indexOf(movie)
    const mid = movies.indexOf(movie)
    movies[mid].fav = !movies[mid].fav;

    this.setState({
      movies: movies
    })
  }
  handleToggleCart = (movie) => {
    let { movies ,cartCount} = this.state
    // const mid= this.state.movies.indexOf(movie)
    const mid = movies.indexOf(movie)
    movies[mid].isInCart = !movies[mid].isInCart;
    console.log('movie cart toggle',movies[mid].isInCart)

    if(movies[mid].isInCart){
      cartCount =cartCount+1
    }
    else{
      cartCount -= 1;
    }

    this.setState({
      movies,
      cartCount
    })

    console.log(cartCount)
  }

  render() {
    const {movies,cartCount}= this.state;
    
      return(
        <>
        <Navbar cartCount={cartCount}/>
          <MovieList movies={movies} addStars={this.handleStar}
            decStars={this.handDecStars}
            toggleFav={this.handleToggleFav}
            toggleCart={this.handleToggleCart}
            key={movies.id} />
      {/* <Student stuname="Alexa" marks={80}/>
      <Student stuname="Seri" marks={90} />
      <Student stuname="Google" marks={70} />
      <Student marks={70} />
      <Student  /> */}
      {/* <HeadingOne />
      <HeadingTwo /> */}
     </>
    )

  };

}

// Student.defaultProps = {
//   stuname: "Student",
//   marks: "N.A"
// }
export default App;





// function App() {
//   return (
//     <>
     
//       <Navbar />
//       <MovieList />
//       {/* <Student stuname="Alexa" marks={80}/>
//       <Student stuname="Seri" marks={90} />
//       <Student stuname="Google" marks={70} />
//       <Student marks={70} />
//       <Student  /> */}
//       {/* <HeadingOne />
//       <HeadingTwo /> */}

//     </>
//   );
// }

// // Student.defaultProps = {
// //   stuname: "Student",
// //   marks: "N.A"
// // }
// export default App;
