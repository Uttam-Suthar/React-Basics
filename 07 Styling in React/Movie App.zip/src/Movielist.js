import React from "react";
import MovieCard from "./Moviecard";
// import { movies } from "./moviesData";
// import { Component } from "react";

// class MovieCard extends Component {}

// class MovieList extends React.Component {
function MovieList(props){


    // render() {
        // const {title, plot, price, rating, stars, fav, isInCart,poster } = this.state.movies
        // const {movies}= this.state
        // const { movies, addStars, decStars, toggleFav, toggleCart, key } = this.props
    const { movies, addStars, decStars, toggleFav, toggleCart, key } = props    // function componet
        // console.log(this.props)
    console.log(props)

        return (
            <>
                {/* <MovieCard title={title} plot={plot} price={price} rating={rating} stars={stars} fav={fav} isInCart={isInCart} /> */}
                {/* { this.state.movies.map((movie)=><MovieCard movies={movie} />)} */}
                {/* {movies.map((movie) => <MovieCard movies={movie} 
                                                addStars={this.handleStar}
                                                decStars={this.handDecStars}
                                                toggleFav={this.handleToggleFav}
                                                toggleCart={this.handleToggleCart}
                                                key={movie.id}/>)} */}

                {movies.map((movie) => <MovieCard movies={movie}
                    addStars={addStars}
                    decStars={decStars}
                    toggleFav={toggleFav}
                    toggleCart={toggleCart}
                    key={key} />)}



                {/* <MovieCard movies={this.state} /> */}


            </>
        );
    // }
}

export default MovieList


// import React from "react";
// import MovieCard from "./Moviecard";
// // import { movies } from "./moviesData";
// // import { Component } from "react";

// // class MovieCard extends Component {}

// class MovieList extends React.Component {

//     // constructor() {
//     //     // super()
//     //     // this.state = {
//     //     //     title: "The Avenger",
//     //     //     plot: "Supernatural power show in movie",
//     //     //     price: 199,
//     //     //     rating: 8.9,
//     //     //     stars: 0,
//     //     //     fav: false,
//     //     //     isInCart: false
//     //     // }

//     //     super()
//     //     this.state = {
//     //         movies:movies,
//     //         cartCount:0
//     //     }

//     //     // this.addStar= this.addStar.bind(this)
//     // }

//     // handleStar=(movie)=>{
//     //     const {movies}= this.state
//     //     // const mid= this.state.movies.indexOf(movie)
//     //     const mid = movies.indexOf(movie)

//     //     if(movies[mid].stars>=5){
//     //         return
//     //     }
//     //     movies[mid].stars += 0.5

//     //     this.setState({
//     //         movies:movies
//     //     })
//     // }

//     // handDecStars = (movie) => {
//     //     const { movies } = this.state
//     //     // const mid= this.state.movies.indexOf(movie)
//     //     const mid = movies.indexOf(movie)

//     //     if (movies[mid].stars <= 0) {
//     //         return
//     //     }
//     //     movies[mid].stars -= 0.5

//     //     this.setState({
//     //         movies: movies
//     //     })
//     // }

//     // handleToggleFav = (movie) => {
//     //     const { movies } = this.state
//     //     // const mid= this.state.movies.indexOf(movie)
//     //     const mid = movies.indexOf(movie)
//     //     movies[mid].fav =!movies[mid].fav;

//     //     this.setState({
//     //         movies: movies
//     //     })
//     // }
//     // handleToggleCart = (movie) => {
//     //     const { movies } = this.state
//     //     // const mid= this.state.movies.indexOf(movie)
//     //     const mid = movies.indexOf(movie)
//     //     movies[mid].isInCart = !movies[mid].isInCart;
//     //     console.log(movies[mid].isInCart)

//     //     this.setState({
//     //         movies: movies
//     //     })
//     // }

//     // addStar=()=>{
//     //     if (this.state.stars >=50) {
//     //         return;
//     //     }
//         // this.state.stars += 0.5
//         // console.log("this state", this.state.stars)
//         // form
//         // this.setState({
//         //     stars: this.state.stars + 0.5

//         // }, () => console.log("stars inside callback", this.state.stars))
//         // this.setState({
//         //     stars:this.state.stars+0.5
        
//         // })
//         // this.setState({
//         //     stars: this.state.stars + 0.5

//         // })
//         // this.setState({
//         //     stars: this.state.stars + 0.5

//         // })
//         // this.setState({
//         //     stars: this.state.stars + 0.5

//         // })

//     //     console.log("stars:", this.state.stars)

//     //     // form 2
        
//     //     this.setState((prevState)=>{
//     //         return {
//     //             stars:prevState.stars+0.5
//     //         }
//     //     })
//     // }
//     render() {
//         // const {title, plot, price, rating, stars, fav, isInCart,poster } = this.state.movies
//         // const {movies}= this.state
//         const { movies,addStars,decStars,toggleFav,toggleCart,key } = this.props
//         console.log(this.props)
//         return (
//             <>
//             {/* <MovieCard title={title} plot={plot} price={price} rating={rating} stars={stars} fav={fav} isInCart={isInCart} /> */}
//                {/* { this.state.movies.map((movie)=><MovieCard movies={movie} />)} */}
//                 {/* {movies.map((movie) => <MovieCard movies={movie} 
//                                                 addStars={this.handleStar}
//                                                 decStars={this.handDecStars}
//                                                 toggleFav={this.handleToggleFav}
//                                                 toggleCart={this.handleToggleCart}
//                                                 key={movie.id}/>)} */}

//                 {movies.map((movie) => <MovieCard movies={movie}
//                     addStars={addStars}
//                     decStars={decStars}
//                     toggleFav={toggleFav}
//                     toggleCart={toggleCart}
//                     key={key} />)}


                
//                 {/* <MovieCard movies={this.state} /> */}
                

//             </>
//         );
//     }
// }

// export default MovieList