// import './HeadingOne'

function HeadingTwo() {
    return (
        <div className="wrapper">
            <h1>HeadingOne</h1>
            <button className="headbtn">Button1</button>
        </div>
    )
}

export default HeadingTwo