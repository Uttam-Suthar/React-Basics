import headStyle from './HeadingOne.module.css'


function HeadingOne(){
    return(
        <div className="wrapper">
            <h1>HeadingOne</h1>
            {/* <button className="head-btn">Button1</button> */}
            <button className={headStyle.headbtn}>Button1</button>

        </div>
    )
}

export default HeadingOne