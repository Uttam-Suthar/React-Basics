import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <form
        style={styles.forms}
      >
        <h3 style={styles.heading}>Sign Up</h3>
        <input style={styles.userinput} placeholder="Username" />
        <input style={styles.emailinput} placeholder="Email" />
        <input style={styles.passwrdinput} placeholder="Password" />
        <div
          style={styles.btndiv}
        >
          <button
            style={styles.btn}
          >
            Cancel
          </button>
          <button
            style={styles.btn}
          >
            Login
          </button>
        </div>
      </form>
    </div>
  );
}


const styles = {
  forms: {
    width: "60%",
    margin: "50px auto",
    display: "flex",
    flexDirection: "column",
    gap: 20
  },
  heading: { fontSize: "2rem", letterSpacing: 2 },
  userinput: { padding: 10 },
  emailinput: { padding: 10 },
  passwrdinput: { padding: 10 },
  btndiv: {
    display: "flex",
    justifyContent: "center",
    gap: 20
  },
  btn: {
    outline: "none",
    paddingBlock: 5,
    width: 100,
    backgroundColor: "red",
    color: "white",
    cursor: "pointer"
  }





}