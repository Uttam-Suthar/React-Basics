You decide to build a TODO App with the following functionality.

Adding text to the input and clicking add should add the new todo to the list and click on the red button should remove it from the list.

You have built individual components like List, Todo, and Form.
You are trying to add a new to-do, but it does not get added to the list.

Find a way to fix this issue.

Expected Output:
<img src="https://res.cloudinary.com/dl26pbek4/image/upload/v1675069374/cn-gifs/todo-app_hrzcm7.gif">
