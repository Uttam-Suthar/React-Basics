### You have learned to use inline styles. To test your knowledge, you decide to change the styling format of a registration form.

Try to change the external CSS to inline CSS by using the same CSS rules.

Note - The style.css file should be empty

Output:
<img src="https://res.cloudinary.com/dzi9rcqsa/image/upload/v1675079298/register_form_myxou4.png">
