import { Component } from "react";
import Course from "./components/Course";
import { courses } from "./data";
import { Container } from "./reusable.styled";

class List extends Component {
  constructor(props) {
    super(props);
    this.state = { bagItems: [] };
  }

  isCourseinBag = (id) => {
    return !!this.state.bagItems.find((c) => c.id === id);
  };

  handleAddToBag = (id) => {
    const course = courses.find((c) => c.id === id);
    this.setState({ bagItems: [course, ...this.state.bagItems] });
    this.props.updateBagItemCount(this.state.bagItems.length + 1);
  };

  handleRemoveFromBag = (id) => {
    const filteredCourses = this.state.bagItems.filter((c) => c.id !== id);
    this.setState({ bagItems: filteredCourses });
    this.props.updateBagItemCount(this.state.bagItems.length - 1);
  };

  render() {
    return (
      <Container>
        {courses.map((v) => (
          <Course
            key={v.id}
            video={v}
            onAdd={this.handleAddToBag}
            onRemove={this.handleRemoveFromBag}
            isInBag={this.isCourseinBag(v.id)}
          />
        ))}
      </Container>
    );
  }
}

export default List;
