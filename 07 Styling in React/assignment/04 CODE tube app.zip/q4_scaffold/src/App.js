import React, { useState } from "react";
import "./styles.css";
import List from "./List";
import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";


export default function App() {
  const [bagItemCount, setBagItemCount] = useState(0);

  const updateBagItemCount = (count) => {
    setBagItemCount(count);
  };
  return (
    <div className="App">
      <Navbar bagItemCount={bagItemCount} />
      <h3>CodeTube Catalog</h3>
      <div className="container">
        <List updateBagItemCount={updateBagItemCount} />
        <Sidebar />
      </div>
    </div>
  );
}
