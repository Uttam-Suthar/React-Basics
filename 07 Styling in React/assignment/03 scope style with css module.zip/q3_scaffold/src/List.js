// import "./list.css";
import Item from "./components/Item";
import { data } from "./data";
import styles from "./list.module.css"

export default function List() {
  return (
    <>
      <h3 className={styles.title}>Items Listed for Sale</h3>
      <div className={styles.container}>
        {data.map((item) => (
          <Item key={item.id} item={item} />
        ))}
      </div>
    </>
  );
}
