export const movies = [{
    title: "The Avengers",
    plot: "Plot of the movie is related to super natural powers",
    price: 199,
    rating: 8.0,
    poster: "https://m.media-amazon.com/images/M/MV5BNDYxNjQyMjAtNTdiOS00NGYwLWFmNTAtNThmYjU5ZGI2YTI1XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg",
    stars: 0,
    fav:false,
    isInCart:false
    },

    {
    title: "Ironman",
    plot: "After being held captive in an Afghan cave, billionaire engineer Tony Stark creates a unique weaponized suit of armor to fight evil.",
    price: 399,
    rating: 8.9,
    poster: "https://m.media-amazon.com/images/M/MV5BNDYxNjQyMjAtNTdiOS00NGYwLWFmNTAtNThmYjU5ZGI2YTI1XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg",
    stars: 0,
    fav:false,
    isInCart:false
    },
    {
    title: "The Avengers",
    plot: "Plot of the movie is related to super natural powers",
    price: 199,
    rating: 8.0,
    poster: "https://m.media-amazon.com/images/M/MV5BNDYxNjQyMjAtNTdiOS00NGYwLWFmNTAtNThmYjU5ZGI2YTI1XkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_SX300.jpg",
    stars: 0,
    fav:false,
    isInCart:false
    },
]